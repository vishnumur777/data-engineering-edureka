#!/bin/bash
echo -e "create 'varuntcs:ecom_txn', 'info'" | hbase shell -n
exit