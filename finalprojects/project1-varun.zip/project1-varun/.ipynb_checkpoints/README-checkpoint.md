# How to run this file

```bash
bash finalrun.sh
```