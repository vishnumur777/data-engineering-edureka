# 1. Top 5 customers with more transactions

![1st.svg](images/1st.svg)